class User:

    def __int__(self, username: str):
        self.username = username